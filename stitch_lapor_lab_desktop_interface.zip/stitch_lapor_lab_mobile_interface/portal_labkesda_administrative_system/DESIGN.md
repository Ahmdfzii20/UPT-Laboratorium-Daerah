---
name: Portal Labkesda Administrative System
colors:
  surface: '#f8f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f8f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f5'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#3f484c'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#eff1f2'
  outline: '#70787c'
  outline-variant: '#bfc8cc'
  surface-tint: '#19677b'
  primary: '#004251'
  on-primary: '#ffffff'
  primary-container: '#005b6f'
  on-primary-container: '#8ed1e8'
  inverse-primary: '#8dd0e7'
  secondary: '#515f74'
  on-secondary: '#ffffff'
  secondary-container: '#d5e3fc'
  on-secondary-container: '#57657a'
  tertiary: '#5b3200'
  on-tertiary: '#ffffff'
  tertiary-container: '#774815'
  on-tertiary-container: '#fbba7c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b4ebff'
  primary-fixed-dim: '#8dd0e7'
  on-primary-fixed: '#001f27'
  on-primary-fixed-variant: '#004e5f'
  secondary-fixed: '#d5e3fc'
  secondary-fixed-dim: '#b9c7df'
  on-secondary-fixed: '#0d1c2e'
  on-secondary-fixed-variant: '#3a485b'
  tertiary-fixed: '#ffdcc0'
  tertiary-fixed-dim: '#fbb97c'
  on-tertiary-fixed: '#2d1600'
  on-tertiary-fixed-variant: '#683c09'
  background: '#f8f9fb'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  title-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-uppercase:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
  table-cell:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  table-header:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  sidebar-expanded: 260px
  sidebar-collapsed: 72px
  container-margin: 24px
  gutter: 16px
  table-row-height: 48px
  table-cell-padding: 12px
---

## Brand & Style

The design system is engineered for **Portal Labkesda**, a high-density administrative dashboard for government health laboratories. The brand personality is rooted in **institutional reliability, transparency, and operational efficiency**. It moves away from the consumer-centric "Lapor Lab" mobile app toward a professional desktop environment that prioritizes data integrity and rapid information processing.

The aesthetic follows a **Corporate / Modern** style with a focus on:
- **Clarity:** Reduced visual noise to assist in long-period administrative focus.
- **Authority:** A structured layout that conveys official government standards.
- **High Information Density:** Optimized for complex data tables and multi-step reporting workflows.
- **Trust:** A "Systematic Neutrality" where the UI stays out of the way of the data, using color only for semantic meaning (status updates and primary actions).

## Colors

This design system utilizes a **Light Mode** default to maintain a paper-like professional quality suitable for government offices. 

- **Primary (#005b6f):** The signature Deep Teal is used for navigation, primary buttons, and active states to maintain continuity with the Lapor Lab brand.
- **Neutral/Secondary:** Slate and Gray tones are used for borders, labels, and disabled states to ensure the UI feels grounded.
- **Semantic Scale:**
    - **Grey (Slate 400):** For Draft/Pending states.
    - **Red (Red 600):** For Late submissions.
    - **Green (Green 600):** For Submitted/Verified records.
    - **Yellow (Yellow 600):** For Revision Requested.
    - **Dark Grey (Slate 700):** For Locked/Archived records.

## Typography

We use **Inter** exclusively for its exceptional legibility in dense data environments. Its tall x-height and clear "tnum" (tabular numeric) properties ensure that columns of figures align perfectly for easy visual scanning.

- **Numeric Data:** Always use `font-variant-numeric: tabular-nums` for table cells.
- **Hierarchy:** Use bold weights sparingly for headers and identifiers to prevent the interface from feeling "heavy."
- **Scale:** The base font size is 14px for general body text, scaling down to 13px for data tables to maximize vertical information density.

## Layout & Spacing

The layout is a **Fixed Sidebar + Fluid Content** model optimized for 1440px displays but responsive down to 1024px.

- **Sidebar:** Left-aligned navigation that can be collapsed to icons-only to reclaim horizontal space for wide data tables.
- **Data Table Grid:** Uses a strict 12-column grid within the content area. Large tables should utilize horizontal scrolling with the first column (usually ID or Name) pinned/frozen.
- **Rhythm:** A 4px/8px baseline grid is used to maintain tight vertical alignment in forms and lists.

## Elevation & Depth

To maintain an official and professional feel, the design system avoids heavy shadows and complex blurs.

- **Tonal Layers:** The background uses a light grey (`#f8fafc`), while cards and the main data area use white (`#ffffff`) to create depth.
- **Low-Contrast Outlines:** Surfaces are defined by 1px solid borders (`#e2e8f0`) rather than shadows. 
- **Active Elevation:** Only the primary action buttons and floating modals use a subtle, 4% opacity ambient shadow to indicate interactivity.
- **Pinned Columns:** Use a subtle right-side border or a very faint gradient transition to indicate that the table content is sliding beneath the frozen column.

## Shapes

The design system uses a **Soft (1)** roundedness profile. This 4px (0.25rem) radius provides a modern touch while maintaining a disciplined, professional structure.

- **Standard Elements:** 4px radius for buttons, input fields, and small cards.
- **Large Containers:** 8px radius for the main dashboard cards.
- **Status Tags:** 2px or fully square corners may be used in extremely dense tables to preserve horizontal space.

## Components

### Data Tables
- **Header:** Sticky headers with sorted icons. Font style: `table-header` (All-caps, Slate 500).
- **Rows:** Alternating zebra striping or 1px bottom borders. Hover state: Light Teal tint (`#f0f9fa`).
- **Frozen Columns:** The primary identifier column is fixed to the left with a subtle vertical separator.

### Sidebar Navigation
- **Active State:** Deep Teal background with white text/icon.
- **Collapsing:** Transition between 260px and 72px. Tooltips must appear on hover in collapsed mode.

### Input Fields
- **Style:** 1px border, 4px radius.
- **Focus:** 2px Deep Teal outline with 0px offset.
- **Validation:** Inline error messages in Red 600, positioned 4px below the input.

### Status Chips
- **Format:** Small, rectangular tags with 2px radius.
- **Coloring:** Background at 10% opacity of the status color, text at 100% opacity (e.g., Green text on light green background for "Submitted").

### Buttons
- **Primary:** Solid Deep Teal with white text.
- **Secondary:** White background with Teal border and text.
- **Ghost:** No border, Teal text, used for secondary actions like "Export" or "Filter."